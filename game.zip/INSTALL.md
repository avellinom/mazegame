## Installation

* Enter the following commands:
    * `opam install ANSITerminal`
    * `opam install graphics`

## Build and Run

* Enter `make play`

### Additional Run Options

* `make doc` and `make opendoc` to open documentation in HTML format
* `make test` to run tests
