type t = unit

let make () : t = ()
